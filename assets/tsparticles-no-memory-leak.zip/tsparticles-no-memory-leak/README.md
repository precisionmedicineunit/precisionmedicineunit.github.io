# tsParticles no memory leak

A Pen created on CodePen.io. Original URL: [https://codepen.io/matteobruni/pen/xxPjwLz](https://codepen.io/matteobruni/pen/xxPjwLz).

